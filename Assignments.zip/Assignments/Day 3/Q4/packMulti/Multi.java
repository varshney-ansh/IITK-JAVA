package packMulti;

public class Multi {
    public int product(int a, int b) {
        return a * b;
    }
}
