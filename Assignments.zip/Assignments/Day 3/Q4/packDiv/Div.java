package packDiv;

public class Div {
    public int divide(int a, int b) {
        return a / b;
    }
}
