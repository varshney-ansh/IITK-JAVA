package packSub;

public class Sub {
    public int diff(int a, int b) {
        return a - b;
    }
}