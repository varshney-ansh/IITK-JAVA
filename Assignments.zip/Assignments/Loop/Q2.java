class Q2 {
    public static void main(String...k){
        System.out.println("Printing All Alphabets....");
        for(char ch = 'A'; ch <= 'Z'; ch++){
            System.out.println(ch);
        }
    }
}
