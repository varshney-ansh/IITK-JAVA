class Q3 {
    public static void main(){
        System.out.println("Printing All Even Numbers between 1 to 100;");
        for(int i = 1; i <= 100; i++){
            if(i%2 == 0){
                System.out.println(i);
            }
        }
    }
}
